package Constructor;

public class Dog5 {
    /*local chain is a process of a constructor of a class calling an other 
	constructor of the same class using th this() method class.*/
	public String name;
	public String breed;
	public int cost;
	
	//constructor
	public Dog5(String name, String breed, int cost) {
		this();
	}
	
	public String getName() {
		return name;
	}
	public String getBreed() {
		return breed;
	}
	public int getCost() {
		return cost;
	}
	
	//zero parameterized constructor
	public Dog5() {
		name = "Rocky";
		breed = "Pug";
		cost = 1254;
	}
}
