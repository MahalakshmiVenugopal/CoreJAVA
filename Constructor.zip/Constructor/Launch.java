package Constructor;

public class Launch {

	public static void main(String[] args) {
		Dog1 d1 = new Dog1("Lobo","BullDog",9999);
		System.out.println(d1.getName());
		System.out.println(d1.getBreed());
		System.out.println(d1.getCost());
		
		Dog2 d2 = new Dog2();
		System.out.println(d2.getName());
		System.out.println(d2.getBreed());
		System.out.println(d2.getCost());
		
		//Dog3 d3 = new Dog3();   //error 
		//System.out.println(d3.getName());
		//System.out.println(d3.getBreed());
		//System.out.println(d3.getCost());
		
		Dog4 d4 = new Dog4();
		System.out.println(d4.getName());
		System.out.println(d4.getBreed());
		System.out.println(d4.getCost());
		
		Dog5 d5 = new Dog5();
		System.out.println(d4.getName());
		System.out.println(d4.getBreed());
		System.out.println(d4.getCost());
		
	}

}
