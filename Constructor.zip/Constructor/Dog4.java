package Constructor;

public class Dog4 {

	//The error 4 in Dog3 can be resolved by providing zero parameterized constructor within class
	public String name;
	public String breed;
	public int cost;
	
	//constructor
	public Dog4(String name, String breed, int cost) {
		this.name = name;
		this.breed = breed;
		this.cost = cost;
	}
	
	public String getName() {
		return name;
	}
	public String getBreed() {
		return breed;
	}
	public int getCost() {
		return cost;
	}
	
	//zero parameterized constructor
	public Dog4() {
		name = "Rocky";
		breed = "Pug";
		cost = 1254;
	}
}
