package Constructor;

public class Dog2 {
	/*if no constructors are provided, Java compiler would automatically insert
	a zero parameterized constructor*/
	
	private String name;
	private String breed;
	private int cost;
	
	public String getName() {
		return name;
	}
	
	public String getBreed() {
		return breed;
	}
	
	public int getCost() {
		return cost;
	}
}
