package Constructor;

public class Dog1 {
	//The first line of the constructor is automatically the super() method column
	public String name;
	public String breed;
	public int cost;
	
	//constructor
	public Dog1(String name, String breed, int cost) {
		this.name = name;
		this.breed = breed;
		this.cost = cost;
	}
	
	public String getName() {
		return name;
	}
	public String getBreed() {
		return breed;
	}
	public int getCost() {
		return cost;
	}
}
