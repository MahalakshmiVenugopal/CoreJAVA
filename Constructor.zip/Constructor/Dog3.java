package Constructor;

public class Dog3 {

	public String name;
	public String breed;
	public int cost;
	
	//constructor
	public Dog3(String name, String breed, int cost) {
		this.name = name;
		this.breed = breed;
		this.cost = cost;
	}
	
	public String getName() {
		return name;
	}
	public String getBreed() {
		return breed;
	}
	public int getCost() {
		return cost;
	}
}
