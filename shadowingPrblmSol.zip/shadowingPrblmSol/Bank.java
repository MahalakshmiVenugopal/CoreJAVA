package shadowingPrblmSol;

public class Bank {
	private String customerName;
	private String accountNo;
	private int depositAmt;
	
	    //setter
		public void setData(String customerName, String accountNo, int depositAmt) {
			this.customerName = customerName;    
			this.accountNo = accountNo;			
			this.depositAmt  = depositAmt;		
		}
		
		//getter
		public String getCustomerName() {
			return customerName;
		}
		
		public String getAccountNo() {
			return accountNo;
		}
		
		public int getDepositAmt() {
			return depositAmt;
		}
}
