package shadowingPrblmSol;

import java.util.Scanner;

public class Launch {
	public static void main(String[] args) {
        Bank b = new Bank();
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the CustomerName");
		String cusName = sc.nextLine();
		System.out.println("Enter the AccountNo");
		String ano = sc.nextLine();
		System.out.println("Enter the amount you want to deposit");
		int amt = sc.nextInt();
		b.setData(cusName, ano, amt);
		
		System.out.println(b.getCustomerName());
		System.out.println(b.getDepositAmt() + " is deposited in " + b.getAccountNo() + " Account ");

	}
}
