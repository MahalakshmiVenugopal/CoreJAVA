package staticKeyword;

public class Launch {

	public static void main(String[] args) {
		
		Demo.disp1();    //static method
		
		Demo d = new Demo();
		d.disp2();

	}

}
