package staticKeyword;

public class Demo2 {

	   //static variables
		static int a,b,c;
		
		//static block
		static
		{
			a=10;
			b=20;
			c=30;
			//m/m for non-static variables are not allocated so, x,y,z cnt be executed
			//x=9;
			//y=99;
			//z=999;
		}
		
		//static method
		static void disp1() {
			System.out.println(a);
			System.out.println(b);
			System.out.println(c);
		}
		
		//non-static variables
		int x,y,z;
		
		
		{
			System.out.println("Inside non-static block");
		}
		
		void disp2() {
			System.out.println("Inside non-static method");
			//Accessing static variables
			System.out.println(a);
			System.out.println(b);
			System.out.println(c);
			//Accessing non-static variables
			System.out.println(x);
			System.out.println(y);
			System.out.println(z);
		}
		
		public Demo2() {
			//constructor
			x=100;
			y=98;
			z=56;
		}
}
