package staticKeyword;

public class Demo {

	//static variables
	static int a,b,c;
	
	//static block
	static
	{
		a=10;
		b=20;
		c=30;
	}
	
	//static method
	static void disp1() {
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
	}
	
	//non-static variables
	int x,y,z;
	
	
	{
		System.out.println("Inside non-static block");
	}
	
	void disp2() {
		System.out.println("Inside non-static method");
		//Accessing static variables
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		//Accessing non-static variables
		System.out.println(x);
		System.out.println(y);
		System.out.println(z);
	}
	
	public Demo() {
		//constructor
		x=100;
		y=98;
		z=56;
	}
	
}
