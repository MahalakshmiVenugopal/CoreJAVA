package staticKeyword.whyStatic;

import java.util.Scanner;

public class FarmerSol {

	private float si;
	private float p;
	private float t;
	static private float r;
	
	static 
	{
		r = 2.5f;
	}
	
	public void acceptInput() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the principal amount");
		p  = sc.nextFloat();
		System.out.println("Enter the time duration");
		t = sc.nextFloat();
	}
	
	public void compute() {
		si = p*t*r;
	}
	
	public void disp() {
		System.out.println(si);
	}
}
