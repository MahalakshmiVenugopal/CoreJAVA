package staticKeyword.whyStatic;

public class Launch {

	public static void main(String[] args) {
		
		Farmer f1 = new Farmer();
		Farmer f2 = new Farmer();
		Farmer f3 = new Farmer();
		
		f1.acceptInput();
		f1.compute();
		f1.disp();
		
		f2.acceptInput();
		f2.compute();
		f2.disp();
		
		f3.acceptInput();
		f3.compute();
		f3.disp();
		
		//static method
		FarmerSol fa = new FarmerSol();
		FarmerSol fb = new FarmerSol();
		FarmerSol fc = new FarmerSol();
		
		fa.acceptInput();
		fa.compute();
		fa.disp();
		
		fb.acceptInput();
		fb.compute();
		fb.disp();
		
		fc.acceptInput();
		fc.compute();
		fc.disp();

	}

}
