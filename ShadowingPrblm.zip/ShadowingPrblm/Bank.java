package ShadowingPrblm;

public class Bank {

	private String customerName;
	private String accountNo;
	private int depositAmt;
	
	    //setter
		public void setData(String customerName, String accountNo, int depositAmt) {
			customerName = customerName;    //null
			accountNo = accountNo;			//null
			depositAmt  = depositAmt;		//0
		}
		
		//getter
		public String getCustomerName() {
			return customerName;
		}
		
		public String getAccountNo() {
			return accountNo;
		}
		
		public int getDepositAmt() {
			return depositAmt;
		}
}
