package exceptionPackage;

public class StackHierarchy {

	public static void main(String[] args) {

		System.out.println("Connection established");
		Gamma g = new Gamma();
		g.gamma();
		System.out.println("Connection terminated");
	}

}
