package exceptionPackage.DiffHandException;

public class CustomException {

	public static void main(String[] args) {

		Bank ba = new Bank();
		ba.initiate();
	}

}
