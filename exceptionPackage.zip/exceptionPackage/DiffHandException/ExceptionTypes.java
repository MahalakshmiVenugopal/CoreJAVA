package exceptionPackage.DiffHandException;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ExceptionTypes {

	public static void main(String[] args) {

		try {
			FileReader file = new FileReader("E:\\ANZ\\CoreJava\\src\\exceptionPackage\\DiffHandException\\Demo.java");
			BufferedReader fileInput = new BufferedReader(file);
			
			//Print first three line of code
			for(int i=0; i<3; i++) {
				System.out.println(fileInput.readLine());
				fileInput.close();
			}
		} catch (FileNotFoundException e) {

			System.out.println("File Not found");
			
		} catch (IOException f) {
			System.out.println("file is empty");
		}
		
	}
	
}
