package exceptionPackage.DiffHandException;

import java.util.Scanner;

public class Alpha {
	public void alpha() {
		System.out.println("Connection alpaha established");
		Scanner sc = new Scanner(System.in);
		try {
			System.out.println("Enter numerator");
			int a = sc.nextInt();
			System.out.println("Enter denominator");
			int b = sc.nextInt();
			int c = a/b;
			System.out.println(c);
		}
		catch(Exception w){
			System.out.println("Exception handled inside alpha");
		}
		System.out.println("Connection alpha terminated");
	}
}
