package exceptionPackage.DiffHandException;

public class ThreeDuckingException {

	public static void main(String[] args) {
		System.out.println("Connection established");
		try {
			Demo3 d = new Demo3();
			d.alpha();
		}
		catch(Exception e) {
			System.out.println("Exception handled inside main()");
		}
		
		System.out.println("Connection terminated");
	}

}
