package exceptionPackage.DiffHandException;

import java.util.Scanner;

public class Demo {

	public void alpha() throws Exception{
		System.out.println("connectionAlpha estblished");
		Scanner sc = new Scanner(System.in);
		try {
			System.out.println("Enter the numerator");
			int a = sc.nextInt();
			System.out.println("Enter the denominator");
			int b = sc.nextInt();
			int c = a/b;
			System.out.println(c);
		}
		catch(Exception e) {
			System.out.println("Exception handled inside alpha()");
			throw e;
		}
		finally {
			System.out.println("Connection terminated");
		}
	}
}
