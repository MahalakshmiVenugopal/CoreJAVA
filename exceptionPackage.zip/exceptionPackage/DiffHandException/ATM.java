package exceptionPackage.DiffHandException;

import java.util.Scanner;

public class ATM {

	int accNo = 2525;
	int passwd = 3535;
	int an;
	int pw;
	
	void acceptInput() {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the accountnumber");
		an = sc.nextInt();
		System.out.println("enter the password");
		pw = sc.nextInt();
	}
	
	void verify() throws Exception{
		if((an==accNo)&&(pw==passwd)) {
			System.out.println("Collect ur money");
		}
		else {
			InvalidException ie = new InvalidException();
			System.out.println(ie.getMessage());
			throw ie;
		}
	}
}
