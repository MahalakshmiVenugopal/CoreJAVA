package exceptionPackage.DiffHandException;

public class OneHandExcep {

	public static void main(String[] args) {

		System.out.println("Connection established");
		Alpha a = new Alpha();
		a.alpha();
		System.out.println("Connection terminated");
	}

}
