package exceptionPackage.DiffHandException;

public class TwoReThrowException {

	public static void main(String[] args) {

		System.out.println("Connection established");
		try {
			Demo d = new Demo();
			d.alpha();
		}
		catch(Exception e) {
			System.out.println("Exception handled inside main()");
		}
		
		System.out.println("Connection terminated");
	}

}
