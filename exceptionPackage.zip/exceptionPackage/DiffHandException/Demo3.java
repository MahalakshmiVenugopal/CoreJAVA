package exceptionPackage.DiffHandException;

import java.util.Scanner;

public class Demo3 {

	public void alpha() throws Exception{
		System.out.println("Connection alpaha established");
		Scanner sc = new Scanner(System.in);
		
			System.out.println("Enter numerator");
			int a = sc.nextInt();
			System.out.println("Enter denominator");
			int b = sc.nextInt();
			int c = a/b;
			System.out.println(c);
		
		System.out.println("Connection alpha terminated");
	}
}
