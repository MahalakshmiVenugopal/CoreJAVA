package exceptionPackage.DiffHandException;

public class Bank {

	public void initiate() {
	
		ATM a = new ATM();
		
		try {
			a.acceptInput();
			a.verify();
		} 
		catch (Exception e) {
			try {
				a.acceptInput();
				a.verify();
			}
			catch(Exception f) {
				try {
					a.acceptInput();
					a.verify();
				}
				catch(Exception g) {
					System.exit(0);
				}
			}
		}
	}
	
}
