package exceptionPackage.DiffHandException;

public class InvalidException extends Exception{

	public String getMessage() {
		return "Invalid inout. Try Again ";
		
	}
}
