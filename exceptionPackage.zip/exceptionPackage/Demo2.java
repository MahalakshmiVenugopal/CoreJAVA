package exceptionPackage;

import java.util.Scanner;

public class Demo2 {

	public static void main(String[] args) {

		System.out.println("Connection established");
		Scanner sc = new Scanner(System.in);
		
		try {
			System.out.println("Enter the numerator");
			int a = sc.nextInt();
			System.out.println("Enter the denominator");
			int b = sc.nextInt();
			int c = a/b;
			System.out.println(c);
			
			System.out.println("Enter the size of the array");
			int size = sc.nextInt();
			int[] x = new int[size];
			
			System.out.println("Enter the element to be stored");
			int element = sc.nextInt();
			
			System.out.println("Enter the position at which the element has to be stored");
			int pos = sc.nextInt();
			x[pos] = element;
			System.out.println(x[pos]);
		}
		catch(Exception e){
			System.out.println("Some problem occur");
		}
		
		System.out.println("Connection terminated");
	}

	
	

}
