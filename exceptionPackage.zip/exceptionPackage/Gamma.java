package exceptionPackage;

public class Gamma {

	public void gamma() {
		System.out.println("ConnectionGamma established");
		Beta b = new Beta();
		b.beta();
		System.out.println("ConnectionGamma terminated");
	}
}
