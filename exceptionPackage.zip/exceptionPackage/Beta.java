package exceptionPackage;

public class Beta {

	public void beta() {
		System.out.println("ConnectionBeta established");
		Alpha a = new Alpha();
		a.alpha();
		System.out.println("ConnectionBeta terminated");
	}
	
}
