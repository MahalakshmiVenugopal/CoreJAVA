package exceptionPackage;

import java.util.Scanner;

public class Alpha {

	public void alpha() {
		System.out.println("ConnectionAlpha established");
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the numerator");
		int a = sc.nextInt();
		System.out.println("Enter the denominator");
		int b = sc.nextInt();
		int c = a/b;
		System.out.println(c);
		System.out.println("ConnectionAlpha is terminated");
	}
}
