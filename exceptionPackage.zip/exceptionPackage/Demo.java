package exceptionPackage;

import java.util.Scanner;

public class Demo {

	public static void main(String[] args) {

		System.out.println("Connection eatablished");
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the numerator");
		int a = sc.nextInt();
		System.out.println("Enter the denominator");
		int b = sc.nextInt();
		int c = a/b;
		System.out.println(c);
		System.out.println("Connection is terminated");
	}

}
