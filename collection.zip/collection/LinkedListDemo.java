package collection;

import java.util.LinkedList;

public class LinkedListDemo {

	public static void main(String[] args) {

		LinkedList ll = new LinkedList();
		ll.add(10);
		ll.add(20);
		ll.add("Rama");
		ll.add(40.4545);
		ll.add('a');
		ll.add(true);
		ll.addFirst(100);
		ll.addLast(20);
		ll.offer(1000);
		ll.offerFirst(2000);
		ll.offerLast(5000);
		ArrayListDemo lld = new ArrayListDemo();
		ll.add(lld);
		System.out.println(ll);
	}

}
