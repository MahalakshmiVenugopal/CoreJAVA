package collection;

import java.util.ArrayDeque;

public class ArrayDequeDemo {

	public static void main(String[] args) {

		ArrayDeque ad = new ArrayDeque();
		ad.add(10);
		ad.add(20);
		ad.add(30);
		ad.addFirst(10);
		ad.addLast(50);
		ad.add(100);
		System.out.println(ad);
		
		
	}

}
