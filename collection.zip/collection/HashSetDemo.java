package collection;

import java.util.HashSet;
import java.util.Iterator;

public class HashSetDemo {

	public static void main(String[] args) {

		HashSet hs = new HashSet();
		hs.add(100);
		hs.add(200);
		hs.add(308);
		hs.add(464);
		System.out.println(hs);
		
		//No duplicates
		//data is not added in indexing apprach
		HashSet<String> hsd = new HashSet<String>();
		hsd.add("John");
		hsd.add("Joe");
		hsd.add("Joe");
		hsd.add("Mikel");
		
		//1.Data is unique, no redundancy
		//2.data is not in order in putput due to hashing	
		System.out.println("set is " + hsd);
		
		Iterator<String> itr = hsd.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
		hsd.remove("Joe");
		
		if(hsd.contains("John")) {
			System.out.println("John is in hsd");
		}
		
		System.out.println("set size is "+ hsd.size());
		
			
	}
}
