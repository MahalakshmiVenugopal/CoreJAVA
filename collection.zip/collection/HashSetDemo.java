package collection;

import java.util.HashSet;

public class HashSetDemo {

	public static void main(String[] args) {

		HashSet hs = new HashSet();
		hs.add(100);
		hs.add(200);
		hs.add(308);
		hs.add(464);
		System.out.println(hs);
	}

}
