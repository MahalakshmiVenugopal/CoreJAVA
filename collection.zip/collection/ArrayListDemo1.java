package collection;

import java.awt.List;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;

public class ArrayListDemo1 {

	public static void main(String[] args) {

		//list can store only String objects
		ArrayList<String> list1 = new ArrayList<String>();
		
		//list can store any tyoe of Object
		ArrayList list2 = new ArrayList();
		
		Student s1 = new Student();
		s1.name = "John";
		s1.rollno = "m102";
		s1.height = 5;
		
		//1.Add data in the list
		list1.add("John");	    //0
		list1.add("Jannie");	//1
		list1.add("Mike");		//2
		list1.add("mk");        //3
		list1.add("Joe");       //4
		
		list2.add("John");
		list2.add(10);
		list2.add(2.2);
		list2.add(list1);
		list2.add(s1);
		
		//print the reference to list -> shall print elements in the list the way we added in sequence
		System.out.println("list1 is " + list1);
		System.out.println("list2 is " + list2);
		
		//2.Get the element form list
		String name = list1.get(2);
		System.out.println("name is "+ name);
		
		Object o = list2.get(2);
		System.out.println("o is "+ o);
		
		//3. Update the elements in list
		list1.set(1, "Fianna");
		System.out.println("list1 now is " + list1);
		
		//Remove the element
		list1.remove(1);
		System.out.println("list1 after removal is " + list1);
		
		//list1.clear(); -> remove all
		
		if(list1.contains("John")) {
			System.out.println("List1 contains John");
		}
		
		//5. Iterate in ArrayList
		System.out.println("Iterating with for loop");
		for(int i=0; i<list1.size(); i++) {
			System.out.println(list1.get(i));
		}
		System.out.println("-----------------------");
		
		System.out.println("iterating with enhanced for loop");
		for(String x: list1) {
			System.out.println(x);
		}
		System.out.println("********************");
		
		System.out.println("acessing through Iterator ");
		Iterator<String> itr = list1.iterator();
		//System.out.println(itr.next());
		//System.out.println(itr.next());
		
		while(itr.hasNext()) {
			String str = itr.next();
			System.out.println(str);
			
			if(str.equals("Joe")) {
				itr.remove();
			}
		}
		System.out.println("*********************");
		
		System.out.println("list1 after iteration" + list1);
		
		//Sorting
		//1. TreeSet
		//2. static method sort()
		System.out.println(list1);
		Collections.sort(list1);
		System.out.println(list1);
		
	}

}
