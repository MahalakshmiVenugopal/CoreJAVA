package collection;

import java.util.TreeSet;

public class TreeSetDemo {

	public static void main(String[] args) {

		TreeSet ts = new TreeSet();
		ts.add(100);
		ts.add(1000);
		ts.add(200);
		ts.add(2000);
		System.out.println(ts);
		
	}

}
