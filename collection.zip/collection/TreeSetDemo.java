package collection;

import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetDemo {

	public static void main(String[] args) {

		TreeSet ts = new TreeSet();
		ts.add(100);
		ts.add(1000);
		ts.add(200);
		ts.add(2000);
		System.out.println(ts);
		
		//No duplicates
				//data is unorderded but it is alphabetically order
				TreeSet<String> hsd = new TreeSet<String>();
				hsd.add("John");
				hsd.add("Joe");
				hsd.add("Joe");
				hsd.add("Mikel");
				
				//1.Data is unique, no redundancy
				//2.data is not in order in putput due to hashing	
				System.out.println("set is " + hsd);
				
				Iterator<String> itr = hsd.iterator();
				while(itr.hasNext()) {
					System.out.println(itr.next());
				}
				
				hsd.remove("Joe");
				
				if(hsd.contains("John")) {
					System.out.println("John is in hsd");
				}
				
				System.out.println("set size is "+ hsd.size());

		
	}

}
