package collection;

import java.util.PriorityQueue;

public class PriorityQueueDemo1 {

	public static void main(String[] args) {

		PriorityQueue<Integer> pq = new PriorityQueue<Integer>();
		
		for(int i=10; i>0; i--) {
			pq.add(i);
		}
		
		//Queue: (Front) 10 9 8 7 6 5 4 3 2 1(rear)
		//PriorityQueue sorts the data for us
		//Queue:(Front) 1 2 3 4 5 6 7 8 9 10(rear) | Sorted Queue the Actual One
		
		//Peeking: Obtaining the head of Queue
		//Polling: removing the head of Queue
		
		System.out.println(pq.peek()); //Head of Queue: 1
		System.out.println(pq);
		
		pq.poll(); //Removing the head
		System.out.println(pq);
		System.out.println(pq.peek()); //New head of queue: 2
		
	}

}
