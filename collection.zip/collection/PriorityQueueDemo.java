package collection;

import java.util.PriorityQueue;

public class PriorityQueueDemo {

	public static void main(String[] args) {

		PriorityQueue pq = new PriorityQueue();
		pq.add(56);
		pq.add(78);
		pq.add(50);
		pq.add(19);
		System.out.println(pq);
	}

}
