package collection;
import collection.Cricketer1;
import java.util.Comparator;

public class Alpha implements Comparator<Cricketer1>{

	@Override
	public int compare(Cricketer1 x, Cricketer1 y) {
		if(x.avg < y.avg) {
			return 1;
		}else {
			return -1;
		}
	}
}
