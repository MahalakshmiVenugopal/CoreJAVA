package collection;

public class Cricketer implements Comparable<Cricketer>{

	String name;
	int runs;
	float avg;
	
	public Cricketer(String name, int runs, float avg) {
		this.name = name;
		this.runs = runs;
		this.avg = avg;
	}
	
	public String getName() {
		return name;
		
	}
	public int getRuns() {
		return runs;	
	}
	public float getAvg() {
		return avg;
	}
	
	public String toString() {
		return name+" "+runs+" "+avg;
	}

	//sorting using comparable interface

	@Override
	public int compareTo(Cricketer o) {
		if(runs < o.runs) {
			return 1;
		}
		else {
			return -1;
		}
	}
	
	
}
