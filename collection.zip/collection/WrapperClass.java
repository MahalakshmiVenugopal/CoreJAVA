package collection;

public class WrapperClass {

	public static void main(String[] args) {

		//primitive data types
		byte a = 45;
		short b = 566;
		int c = 9874;
		long d = 12365478l;
		float e = 45.5f;
		double f = 454.2245;
		char g = 'c';
		boolean h = false;
		
		//Wrapper Class
		Byte a1 = new Byte((byte) 5);
		Short b1 = new Short((short) 566);
		Integer c1 = new Integer(9874);
		Long d1 = new Long(12365478l);
		Float e1 = new Float(45.5f);
		Double f1 = new Double(454.2245);
		Character g1 = new Character('a');
		Boolean h1 = new Boolean(false);
		
		//boxing
		int x = 45;
		System.out.println(x);
		Integer x1 = new Integer(45);
		System.out.println(x1);
		//AutoBoxing
		Integer x11 = 45;
		
		//Unboxing
		Integer y = new Integer(10);
		int z = y.intValue();
		System.out.println(y);
		System.out.print(z);
	}

}
