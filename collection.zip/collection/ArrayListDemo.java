package collection;
import java.util.*;
import java.util.ArrayList;

import javax.swing.text.html.HTMLDocument.Iterator;

public class ArrayListDemo {

	public static void main(String[] args) {

		ArrayList al = new ArrayList();
		al.add(10);
		al.add(20);
		al.add("Rama");
		al.add(40.4545);
		al.add('a');
		al.add(true);
		ArrayListDemo ald = new ArrayListDemo();
		al.add(ald);
		System.out.println(al);
		
		ArrayList al2 = new ArrayList();
		al2.add(100);
		al2.add(200);
		al2.add(300);
		al2.add(400);
		System.out.println(al2);
		al.addAll(al2);
		System.out.println(al);
		
		ArrayList al3 = new ArrayList();
		al3.add(1000);
		al3.add(2000);
		al3.add(3000);
		al3.add(4000);
		System.out.println(al3);
		al.addAll(2, al3);
		System.out.println(al);
		al.add(3000);
		al.add(75);
		al.add(90.3);
		System.out.println(al);
		
		System.out.println(al.contains(3000));
		System.out.println(al.contains(999));
		
		System.out.println(al.indexOf(3000));
		System.out.println(al.lastIndexOf(3000));
		
		System.out.println(al.get(14));
		System.out.println(al.getClass());
		
		System.out.println(al.isEmpty());
		al.clear();
		System.out.println(al.isEmpty());
		
		ArrayList al4 = new ArrayList();
		al.ensureCapacity(100);
		System.out.println(al4.size());
		al4.add(10);
		al4.add(20);
		al4.add(30);
		System.out.println(al4.size());
		al.trimToSize();
		System.out.println(al4.size());
		
		//retailAll()
		ArrayList al5 = new ArrayList();
		al5.add(10);
		al5.add(20);
		System.out.println(al5);
		ArrayList al6 = new ArrayList();
		al6.add(10);
		al6.add(13);
		System.out.println(al6);
		al5.retainAll(al6);
		System.out.println(al5);
		
		//add() and set()
		ArrayList al7 = new ArrayList();
		al7.add(10);
		al7.add(20);
		al7.add(30);
		al7.add(56);
		al7.add(89);
		al7.add(48);
		System.out.println(al7);
		//al.add(4, 99);
		//System.out.println(al7);
		//al.set(1, 99);
		//System.out.println(al7);
		
		//accessing objects for-loop
		ArrayList al8 = new ArrayList();
		al8.add(1);
		al8.add(2);
		al8.add(3);
		al8.add(4);
		//for(int i=0; i<=al8.size()-1; i++) {
			//System.out.println(al.get(i));
		//}
	
		//accessing objects enhanced for-loop
		for(Object x : al8) {
			System.out.println(x);
		}
		
		//accessing using iterator
		//Iterator itr = al8.Iterator();
		//while(itr.hasNext()==true) {
			//System.out.println(itr.next();
		//}
		
		//accessing ListIterator
		//ListIterator li = al8.ListIterator();
		//while(itr.hasNext()==true) {
		//System.out.println(itr.next();
	    //}
		
		//ListIterator li = al8.ListIterator(al8.size());
		//while(itr.hasPrevious()==true) {
		//	System.out.println(itr.Previous());
		//}
		
		//ListIterator li = al8.ListIterator(al8.size());
				//while(itr.hasPrevious()==true) {
				//	System.out.println(itr.Previous());
				//}
		
		//ListIterator li = al8.descendingIterator(al8.size());
		//while(itr.hasPrevious()==true) {
		//	System.out.println(itr.Previous());
		//}
		
		Vector v = new Vector();
		v.add(al8);
		v.add(al7);
		v.add(10);
		Enumeration itr = v.elements();
		while(itr.hasMoreElements()) {
			System.out.println(itr.nextElement());
		}

	}

}
