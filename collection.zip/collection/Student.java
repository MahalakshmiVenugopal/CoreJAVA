package collection;

public class Student {

	String name;
	String rollno;
	int height;
}
