package abstractClassInterface;

public abstract class Plane {

	abstract void takeOff();
	abstract void fly();
	abstract void land();
}
