package abstractClassInterface;

public class Calculator1 implements MyCalculator{

	@Override
	public void add() {

		int a = 20;
		int b = 30;
		int c = a+b;
		System.out.println(c);
	}

	@Override
	public void sub() {
		
		int a = 20;
		int b = 10;
		int c = a-b;
		System.out.println(c);
		
	}

	
}
