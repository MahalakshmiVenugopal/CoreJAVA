package abstractClassInterface;

public class CargoPlane extends Plane{

		@Override
		void takeOff() {
			System.out.println("CargoPlane is takingOff");
		}

		@Override
		void fly() {
			System.out.println("CargoPlane is flying");			
		}
		
		@Override
		void land() {
			System.out.println("CargoPlane is landing");
		}

}
