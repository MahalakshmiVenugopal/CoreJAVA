package abstractClassInterface;

import java.util.Scanner;

public class Calculator2 implements MyCalculator{

	@Override
	public void add() {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first number");
		int a = sc.nextInt();
		System.out.println("Enter the second number");
		int b = sc.nextInt();
		int c = a+b;
		System.out.println(c);
	}

	@Override
	public void sub() {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first number");
		int a = sc.nextInt();
		System.out.println("Enter the second number");
		int b = sc.nextInt();
		int c = a-b;
		System.out.println(c);
	}

}
