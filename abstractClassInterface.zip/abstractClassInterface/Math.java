package abstractClassInterface;

public class Math {

	public void permit(MyCalculator c) {
		c.add();
		c.sub();
	}
}
