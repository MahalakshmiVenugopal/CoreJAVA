package abstractClassInterface;

public class PassengerPlane extends Plane{

	@Override
	void takeOff() {
		System.out.println("PassengerPlane is takingOff");
	}

	@Override
	void fly() {
		System.out.println("PassengerPlane is flying");			
	}
	
	@Override
	void land() {
		System.out.println("PassengerPlane is landing");
	}

}
