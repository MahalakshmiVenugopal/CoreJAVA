package abstractClassInterface;

public class InterfaceClass {

	public static void main(String[] args) {

		Calculator1 c1 = new Calculator1();
		Calculator2 c2 = new Calculator2();
		Calculator3 c3 = new Calculator3();
		
		Math m = new Math();
		
		m.permit(c1);
		m.permit(c2);
		m.permit(c3);
	}

}
