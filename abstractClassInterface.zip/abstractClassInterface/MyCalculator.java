package abstractClassInterface;

interface MyCalculator {
	
	public void add();
	public void sub();

}
