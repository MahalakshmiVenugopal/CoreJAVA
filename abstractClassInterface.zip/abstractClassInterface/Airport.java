package abstractClassInterface;

public class Airport {

	public void permit(Plane ref) {
		ref.takeOff();
		ref.fly();
		ref.land();
	}
}
