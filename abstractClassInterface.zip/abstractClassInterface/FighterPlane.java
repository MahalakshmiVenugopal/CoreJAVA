package abstractClassInterface;

public class FighterPlane extends Plane{

	@Override
	void takeOff() {
		System.out.println("FighterPlane is takingOff");
	}

	@Override
	void fly() {
		System.out.println("FighterPlane is flying");			
	}
	
	@Override
	void land() {
		System.out.println("FighterPlane is landing");
	}


}
