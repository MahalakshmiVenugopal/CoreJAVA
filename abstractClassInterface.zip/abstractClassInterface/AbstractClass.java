package abstractClassInterface;

public class AbstractClass {

	public static void main(String[] args) {
		CargoPlane cp = new CargoPlane();
		PassengerPlane pp = new PassengerPlane();
		FighterPlane fp = new FighterPlane();
		
		Airport a = new Airport();
		a.permit(cp);
		a.permit(pp);
		a.permit(fp);
	}

}
