package polymorphism;

public class PassengerPlane extends Plane{

	public void takeOff() {
		System.out.println("PassengerPlane is takeingOff");
	}
	
	public void fly() {
		System.out.println("PassengerPlane is flying");
	}
	
	public void land() {
		System.out.println("PassengerPlane is landing");
	}
	
}
