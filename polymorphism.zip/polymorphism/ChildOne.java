package polymorphism;

public class ChildOne extends Parent{

	public void disp() {
		System.out.println("Child1");
	}
	
	public void eat() {
		System.out.println("Child1 eeats");
	}
}
