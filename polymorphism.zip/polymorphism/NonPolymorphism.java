package polymorphism;

public class NonPolymorphism {

	public static void main(String[] args) {

		//tight coupling
		ChildOne c1 = new ChildOne();
		ChildTwo c2 = new ChildTwo();
		Child3 c3 = new Child3();
		
		//3 statements 3 ouputs;
		c1.disp();
		c2.disp();
		c3.disp();
	}

}
