package polymorphism;

public class PassByValue {
	
	public static void changeVariable(int a) {
		a = a + 10;
		System.out.println("Inside chanageVariable method and value of a is " + a);
	}

	public static void main(String[] args) {

		int a = 4;  //local primitive variable
		System.out.println("Value of a before calling is " + a);
		changeVariable(a);
		System.out.println("Value of a after callinng is "+ a);
		
		System.out.println("---------------------------------");
		
		int x = 5000;
		int y;
		y = x;
		System.out.println(x);
		System.out.print(y);
		
	}

}
