package polymorphism;

public class Parent {

	public void disp() {
		System.out.println("parent");
	}
	
}
