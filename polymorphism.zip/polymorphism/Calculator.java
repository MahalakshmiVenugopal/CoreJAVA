package polymorphism;

public class Calculator {

	int add(int x, int y) {
		return x+y;
	}
	
	double add(int x, double y) {
		return x+y;
	
	}
	
	float add(int x, float y) {
		return x+y;
	}
	
	float add(float x, float y) {
		return x+y;
	}
	
	double add(double x, double y) {
		return x+y;
	}
	
	float add(float x, int y) {
		return x+y;
	}
	
	double add(float x, double y) {
		return x+y;
	}
	
	int add(int x, int y, int z) {
		return x+y+z;
	}
	
	double add(float x, int y, double z) {
		return x+y+z;
	}
	
	double add(double x, double y, double z) {
		return x+y+z;
	}
	
	double add(int x, float y, double z) {
		return x+y+z;
	}
}
