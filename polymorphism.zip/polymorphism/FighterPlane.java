package polymorphism;

public class FighterPlane extends Plane{

	public void takeOff() {
		System.out.println("FighterPlane is takeingOff");
	}
	
	public void fly() {
		System.out.println("FighterPlane is flying");
	}
	
	public void land() {
		System.out.println("FighterPlane is landing");
	}
}
