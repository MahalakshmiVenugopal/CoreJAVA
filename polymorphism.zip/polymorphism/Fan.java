package polymorphism;

public class Fan {

	String brand;
	int no_of_blades;
	int cost;
}
