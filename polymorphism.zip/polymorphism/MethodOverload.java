package polymorphism;

public class MethodOverload {

	public static void main(String[] args) {

		int a=10, b=20, c=30;
		float p=10.5f, q=11.5f, r=45.2f;
		double x=1000.562, y=12.56324, z=564.4578;
		
		Calculator calc = new Calculator();
		System.out.println(calc.add(p, a, x));
		System.out.println(calc.add(p, q));
		System.out.println(calc.add(a, p));
				
	}

}
