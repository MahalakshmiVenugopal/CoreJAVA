package polymorphism;

public class Child3 extends Parent{

	public void disp() {
		System.out.println("Child3");
	}
}
