package polymorphism;

public class CargoPlane extends Plane{

	 public void takeOff() {
		System.out.println("CargoPlane is taking Off from long-sized runway");
	}
	public void fly() {
		System.out.println("CargoPlane is flying at low heights");
	}
    
	public void land() {
		System.out.println("CargoPlane is landing on long-sized runway");
	}
}
