package polymorphism;

public class ChildTwo extends Parent{

	public void disp() {
		System.out.println("Child2");
	}
}
