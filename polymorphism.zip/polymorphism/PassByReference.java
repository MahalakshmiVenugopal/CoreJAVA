package polymorphism;

public class PassByReference {

	public static void main(String[] args) {

		Fan a = new Fan();
		a.brand = "USHA";
		a.no_of_blades = 3;
		a.cost = 1000;
		System.out.println(a.brand);
		System.out.println(a.no_of_blades);
		System.out.println(a.cost);
		
		Fan b = new Fan();
		b = a;
		//b.brand = "khaithan";
		//b.no_of_blades = 4;
		//b.cost = 2000;
		System.out.println(b.brand);
		System.out.println(b.no_of_blades);
		System.out.println(b.cost);
		
	}

}
