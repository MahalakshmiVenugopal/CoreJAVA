package polymorphism;

public class Polymorphism {

	public static void main(String[] args) {

		//loose coupling
		ChildOne c1 = new ChildOne();
		ChildTwo c2 = new ChildTwo();
		Child3 c3 = new Child3();
				
		Parent ref;
		//1 statement 
		ref = c1;
		ref.disp();
		((ChildOne)(ref)).eat(); //downcasting to access specialised method through parent ref
		
		ref = c2;
		ref.disp();
		
		ref = c3;
		ref.disp();
	}

}
