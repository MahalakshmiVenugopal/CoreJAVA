package aggregationComposition;

public class MobileCom {

	OS os = new OS("ANdroid", 512);
}
