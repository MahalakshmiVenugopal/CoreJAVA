package aggregationComposition;

public class OS {

	String name;
	int size;

	public OS(String name, int size) {
		this.name = name;
		this.size  = size;
	}
	
	public String getName() {
		return name;
	}
	
	public int getSize() {
		return size;
	}
}
