package aggregationComposition;

public class MobileAgg {

	public void hasA(Charger c) {
		System.out.println(c.brand);
		System.out.println(c.voltage);
	}
}
