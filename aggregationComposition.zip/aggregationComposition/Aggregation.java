package aggregationComposition;

public class Aggregation {

	public static void main() {
		MobileAgg m = new MobileAgg();
		
		Charger c = new Charger("Samsung", 45.5f);
		
		//m.hasA(c);
		
		//m = null;
		
		//m.hasA(c);
		
		System.out.println(c.getBrand());
		System.out.println(c.getVoltage());
	}
}
