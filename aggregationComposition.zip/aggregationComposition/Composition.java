package aggregationComposition;

public class Composition {

	public static void main(String[] args) {
		MobileCom m = new MobileCom();
		
		System.out.println(m.os.getName());
		System.out.println(m.os.getSize());
		
		m = null;
		
		//System.out.println(m.os.getName());
		//System.out.println(m.os.getSize());

	}

}
