package inheritance;

public class PassengerPlane extends Plane{

	public void fly() {
		System.out.println("Passenger is flying");
	}
    
	public void carryPassenger() {
		System.out.println("PassengerPlane is carrying Passenger");
	}
}
