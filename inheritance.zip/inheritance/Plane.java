package inheritance;

public class Plane {

	public void takeOff() {
		System.out.println("Plane is takingoff");
	}
	
	public void fly() {
		System.out.println("Plane is flying");
	}
	
	public void land() {
		System.out.println("Plane is landing");
	}
}
