package inheritance;

public class InheritanceMethods {

	public static void main(String[] args) {
		
		CargoPlane cp = new CargoPlane();
		PassengerPlane pp = new PassengerPlane();
		
		cp.takeOff();    //inherited method
		cp.fly();        //overriddden method
		cp.land();	     //inherited method
		cp.carryCargo(); //specialised method
		
		pp.takeOff();
		pp.fly();
		pp.land();
		pp.carryPassenger();
	}

}
