package inheritance;

public class CargoPlane extends Plane{
		
		public void fly() {
			System.out.println("CargoPlane is flying");
		}
	    
		public void carryCargo() {
			System.out.println("CargoPlane is carrying cargo");
		}
}
