package inheritance;

public class Demo2 extends Demo1{
	
	public void disp2() {
		System.out.println("Inside disp2");
	}
}
