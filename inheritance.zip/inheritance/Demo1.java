package inheritance;

public class Demo1 {
	public void disp1() {
		System.out.println("Inside disp1");
	}
}
