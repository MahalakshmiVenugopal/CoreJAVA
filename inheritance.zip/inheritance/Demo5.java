package inheritance;

public class Demo5 extends Demo1{

	public void disp5() {
		System.out.println("Inside disp5");
	}
}
