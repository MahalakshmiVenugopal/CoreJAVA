package inheritance;

public class Demo3 extends Demo2{
	public void disp3() {
		System.out.println("Inside disp3");
	}
}
