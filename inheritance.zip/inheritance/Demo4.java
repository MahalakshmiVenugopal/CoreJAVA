package inheritance;

public class Demo4 extends Demo1{
	
	public void disp4() {
		System.out.println("Inside disp4");
	}

}
