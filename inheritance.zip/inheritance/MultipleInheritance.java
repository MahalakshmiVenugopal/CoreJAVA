package inheritance;

public class MultipleInheritance {

	public static void main(String[] args) {
		
		Demo3 d3 = new Demo3();
		d3.disp1();
		d3.disp2();
		d3.disp3();
	}

}
