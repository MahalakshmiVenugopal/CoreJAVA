package inheritance;

public class Hierarchical {

	public static void main(String[] args) {
		
		Demo2 d2 = new Demo2();
		d2.disp1();
		d2.disp2();
		
		Demo4 d4 = new Demo4();
		d4.disp1();
		d4.disp4();
		
		Demo5 d5 = new Demo5();
		d5.disp1();
		d5.disp5();

	}

}
